#Requires -Version 5.1
<#
  Rabbit Kit installer / uninstaller.

  Modes:
    (default)     fresh install or install-over-the-top
    -Update       install over the top, skip the one-time bootstrap work
    -Clean        remove the old install dir first, then install (Reinstall)
    -Uninstall    remove the install dir, scheduled tasks, shortcuts and file
                  associations. User data in Documents\Rabbit Kit Data is
                  NEVER touched by any of these modes.

  Progress: every step prints "==> [n/N] message" on stdout so the setup GUI can
  drive a determinate progress bar. Keep that format if you add steps, and keep
  Set-StepTotal in sync.
#>
param(
  [string]$InstallDir = "$env:LOCALAPPDATA\Programs\RabbitKit",
  [string]$PayloadZip = "",
  [switch]$Quiet,
  [switch]$Update,
  [switch]$Clean,
  [switch]$Uninstall,
  [switch]$NoStartup,
  [switch]$BootstrapOnly
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# User data lives here and is never removed by this script. It is stated out
# loud in the setup UI too, because "uninstall" eating someone's notes is the
# kind of surprise you only get to deliver once.
$DataDirName = "Rabbit Kit Data"

$script:StepIndex = 0
$script:StepTotal = 1

function Set-StepTotal($n) { $script:StepTotal = $n }

function Write-Step($msg) {
  $script:StepIndex++
  Write-Host ""
  Write-Host ("==> [{0}/{1}] {2}" -f $script:StepIndex, $script:StepTotal, $msg) -ForegroundColor Cyan
}

function Ensure-Dir($p) {
  if (-not (Test-Path $p)) { New-Item -ItemType Directory -Path $p | Out-Null }
}

function Find-Python {
  # Rabbit Kit owns its runtime. Never depend on PATH, winget, or a system
  # Python whose version/packages can change independently of the app.
  $privatePython = Join-Path $InstallDir "python\python.exe"
  if (Test-Path -LiteralPath $privatePython) {
    try {
      $ver = & $privatePython -c "import sys; print(f'{sys.version_info[0]}.{sys.version_info[1]}')" 2>$null
      if ($LASTEXITCODE -eq 0 -and $ver -eq "3.12") {
        return $privatePython
      }
    } catch {}
  }
  return $null
}

function Install-Python {
  Write-Host "Installing Rabbit Kit's private Python 3.12 runtime…"
  $embedDir = Join-Path $InstallDir "python"
  if (Test-Path -LiteralPath $embedDir) {
    Remove-Item -LiteralPath $embedDir -Recurse -Force
  }
  Ensure-Dir $embedDir
  $token = [Guid]::NewGuid().ToString("N")
  $zip = Join-Path $env:TEMP "rabbitkit-python-$token.zip"
  $url = "https://www.python.org/ftp/python/3.12.10/python-3.12.10-embed-amd64.zip"
  Write-Host "Downloading Python 3.12.10 from python.org…"
  Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing
  if (-not (Test-Path -LiteralPath $zip) -or (Get-Item $zip).Length -lt 1MB) {
    throw "The Python runtime download was incomplete."
  }
  Expand-Archive -Path $zip -DestinationPath $embedDir -Force
  Remove-Item $zip -Force -ErrorAction SilentlyContinue

  # Enable site-packages + pip
  $pth = Get-ChildItem $embedDir -Filter "python*._pth" | Select-Object -First 1
  if ($pth) {
    $text = Get-Content $pth.FullName
    $text = $text | ForEach-Object { if ($_ -match '^#import site') { 'import site' } else { $_ } }
    if ($text -notcontains 'import site') { $text += 'import site' }
    Set-Content $pth.FullName $text
  }
  $getPip = Join-Path $env:TEMP "rabbitkit-get-pip-$token.py"
  Invoke-WebRequest -Uri "https://bootstrap.pypa.io/get-pip.py" -OutFile $getPip -UseBasicParsing
  $pyExe = Join-Path $embedDir "python.exe"
  & $pyExe $getPip --no-warn-script-location |
    ForEach-Object { Write-Host $_ }
  if ($LASTEXITCODE -ne 0) {
    throw "Installing pip into Rabbit Kit's private Python failed with code $LASTEXITCODE."
  }
  Remove-Item $getPip -Force -ErrorAction SilentlyContinue
  & $pyExe -m pip --version |
    ForEach-Object { Write-Host $_ }
  if ($LASTEXITCODE -ne 0) {
    throw "Rabbit Kit's private Python could not start pip."
  }
  return $pyExe
}

# ffmpeg is deliberately NOT installed here. It was ~150 MB of the install and
# nothing at boot touches it -- rabbit_kit.py resolves it at runtime and reports
# "ffmpeg not found" cleanly when it is absent. It ships as the Video Studio
# plugin instead, installed on demand from the Plugins window.

function Install-WebView2 {
  $marker = "${env:ProgramFiles(x86)}\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"
  $runtime = "${env:ProgramFiles(x86)}\Microsoft\EdgeWebView\Application"
  if ((Test-Path $runtime) -or (Test-Path $marker)) {
    Write-Host "WebView2 runtime present"
    return
  }
  Write-Host "Installing WebView2 Runtime…"
  $boot = Join-Path $env:TEMP "MicrosoftEdgeWebview2Setup.exe"
  Invoke-WebRequest -Uri "https://go.microsoft.com/fwlink/p/?LinkId=2124703" -OutFile $boot -UseBasicParsing
  $webViewInstall = Start-Process -FilePath $boot -ArgumentList "/silent","/install" -Wait -PassThru
  Remove-Item $boot -Force -ErrorAction SilentlyContinue
  if ($webViewInstall.ExitCode -ne 0 -and
      -not (Test-Path "${env:ProgramFiles(x86)}\Microsoft\EdgeWebView\Application")) {
    throw "WebView2 installation failed with code $($webViewInstall.ExitCode)."
  }
}

function New-Shortcut($path, $target, $args, $workDir, $icon) {
  $w = New-Object -ComObject WScript.Shell
  $s = $w.CreateShortcut($path)
  $s.TargetPath = $target
  if ($args) { $s.Arguments = $args }
  $s.WorkingDirectory = $workDir
  if ($icon -and (Test-Path $icon)) { $s.IconLocation = $icon }
  $s.Save()
}

# ---- removal helpers (shared by -Uninstall and -Clean) ----

$FileKinds = [ordered]@{
  "Image" = @(".png",".jpg",".jpeg",".gif",".webp",".bmp",".ico",".tif",".tiff")
  "Video" = @(".mp4",".mkv",".webm",".mov",".avi",".m4v")
  "Audio" = @(".mp3",".wav",".flac",".ogg",".m4a",".aac",".opus")
  "Text"  = @(".txt",".md",".log",".json",".xml",".csv",".ini",".yml",".yaml")
}

function Invoke-Schtasks {
  # Native stderr under $ErrorActionPreference = "Stop" turns into a terminating
  # NativeCommandError, and every schtasks call here is best-effort cleanup.
  param([string[]]$Arguments)
  try {
    $old = $ErrorActionPreference
    $ErrorActionPreference = "SilentlyContinue"
    & schtasks.exe @Arguments 2>&1 | Out-Null
    $ErrorActionPreference = $old
  } catch {
    $ErrorActionPreference = "Stop"
  }
}

function Stop-RabbitKit {
  # Files under the install dir stay locked while the app is running, so a
  # remove would half-succeed and leave a broken folder behind.
  foreach ($t in @("Rabbit Kit Background","Rabbit Kit Open")) {
    Invoke-Schtasks @("/End", "/TN", $t)
  }
  $target = [IO.Path]::GetFullPath($InstallDir).TrimEnd('\')
  try {
    $procs = Get-CimInstance Win32_Process -Filter "Name='pythonw.exe' OR Name='python.exe' OR Name='RabbitOpen.exe'" -ErrorAction SilentlyContinue
    foreach ($p in $procs) {
      $line = $p.CommandLine
      if (-not $line) { continue }
      if ($line -like "*rabbit_kit.py*" -or $line -like "*$target*") {
        Write-Host "Closing running Rabbit Kit (pid $($p.ProcessId))…"
        Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue
      }
    }
  } catch {}
  Start-Sleep -Milliseconds 600
}

function Remove-RabbitTasks {
  foreach ($t in @("Rabbit Kit Background","Rabbit Kit Open")) {
    try {
      $existing = Get-ScheduledTask -TaskName $t -ErrorAction SilentlyContinue
      if ($existing) {
        Unregister-ScheduledTask -TaskName $t -Confirm:$false -ErrorAction Stop
        Write-Host "Removed scheduled task: $t"
      }
    } catch {
      # Older boxes without the ScheduledTasks module still have schtasks.exe.
      Invoke-Schtasks @("/Delete", "/TN", $t, "/F")
    }
  }
}

function Remove-RabbitShortcuts {
  $paths = @(
    (Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Rabbit Kit.lnk"),
    (Join-Path ([Environment]::GetFolderPath("Desktop")) "Rabbit Kit.lnk")
  )
  foreach ($p in $paths) {
    if (Test-Path -LiteralPath $p) {
      Remove-Item -LiteralPath $p -Force -ErrorAction SilentlyContinue
      Write-Host "Removed shortcut: $p"
    }
  }
}

function Remove-RabbitFileTypes {
  foreach ($kind in $FileKinds.Keys) {
    $progId = "RabbitKit.$kind"
    $base = "HKCU:\Software\Classes\$progId"
    if (Test-Path $base) {
      Remove-Item -Path $base -Recurse -Force -ErrorAction SilentlyContinue
    }
    foreach ($ext in $FileKinds[$kind]) {
      # Only our own entry goes; the extension key itself belongs to whatever
      # else the user has associated and must survive.
      $withKey = "HKCU:\Software\Classes\$ext\OpenWithProgids"
      if (Test-Path $withKey) {
        Remove-ItemProperty -Path $withKey -Name $progId -Force -ErrorAction SilentlyContinue
      }
    }
  }
  Write-Host "Removed Image/Video/Audio/Text handlers"
}

function Remove-RabbitInstallDir {
  if (-not (Test-Path -LiteralPath $InstallDir)) {
    Write-Host "Nothing to remove at $InstallDir"
    return
  }
  for ($i = 0; $i -lt 5; $i++) {
    try {
      Remove-Item -LiteralPath $InstallDir -Recurse -Force -ErrorAction Stop
      Write-Host "Removed $InstallDir"
      return
    } catch {
      Start-Sleep -Milliseconds 700
    }
  }
  # A stubborn lock should not read as a silent success.
  if (Test-Path -LiteralPath $InstallDir) {
    throw "Could not fully remove $InstallDir - close Rabbit Kit and try again."
  }
}

# ---- uninstall ----
if ($Uninstall) {
  Set-StepTotal 4
  Write-Host "Rabbit Kit Uninstall"
  Write-Host "Removing: $InstallDir"

  Write-Step "Stopping Rabbit Kit and removing scheduled tasks"
  Stop-RabbitKit
  Remove-RabbitTasks

  Write-Step "Removing shortcuts"
  Remove-RabbitShortcuts

  Write-Step "Removing file associations"
  Remove-RabbitFileTypes

  Write-Step "Removing program files"
  Remove-RabbitInstallDir

  $dataDir = Join-Path ([Environment]::GetFolderPath("MyDocuments")) $DataDirName
  Write-Host ""
  Write-Host "Rabbit Kit has been uninstalled." -ForegroundColor Green
  Write-Host "Your notes, macros and snapshots were kept in:"
  Write-Host "  $dataDir"
  if (-not $Quiet) {
    Write-Host "Press Enter to close."
    [void][Console]::ReadLine()
  }
  exit 0
}

# ---- main install ----
$total = 7
if (-not $Update) { $total = $total + 1 }
if ($Clean) { $total = $total + 1 }
Set-StepTotal $total

if ($Clean) { Write-Host "Rabbit Kit Reinstall" }
elseif ($Update) { Write-Host "Rabbit Kit Update" }
else { Write-Host "Rabbit Kit Setup" }
Write-Host "Install to: $InstallDir"

if ($Clean) {
  Write-Step "Removing the previous installation"
  Stop-RabbitKit
  Remove-RabbitTasks
  Remove-RabbitInstallDir
}

Ensure-Dir $InstallDir

Write-Step "Extracting Rabbit Kit"
if (-not $PayloadZip -or -not (Test-Path $PayloadZip)) {
  throw "Payload zip not found: $PayloadZip"
}
Expand-Archive -Path $PayloadZip -DestinationPath $InstallDir -Force

Write-Step "Preparing Rabbit Kit's private Python"
$py = Find-Python
if (-not $py) { $py = Install-Python }
if (-not $py) { throw "Could not install Rabbit Kit's private Python runtime." }
Write-Host "Python: $py"

if (-not $Update) {
  Write-Step "Checking the WebView2 runtime"
  Install-WebView2
}

Write-Step "Installing Python packages"
if (-not $Update) {
  & $py -m pip install --upgrade pip setuptools wheel --disable-pip-version-check
  if ($LASTEXITCODE -ne 0) {
    throw "Preparing pip, setuptools, and wheel failed with code $LASTEXITCODE."
  }
}
$req = Join-Path $InstallDir "requirements.txt"
& $py -m pip install -r $req --no-build-isolation --disable-pip-version-check
if ($LASTEXITCODE -ne 0) {
  throw "Installing Rabbit Kit's Python packages failed with code $LASTEXITCODE."
}
if ($BootstrapOnly) {
  Write-Host "Dependency bootstrap completed successfully."
  exit 0
}

Write-Step "Creating shortcuts"
$vbs = Join-Path $InstallDir "Rabbit Kit.vbs"
# Point VBS at the resolved pythonw next to python.exe when possible
$pyDir = Split-Path $py -Parent
$pythonw = Join-Path $pyDir "pythonw.exe"
if (-not (Test-Path $pythonw)) { $pythonw = $py }
# pythonw + window style 0 = no console window at any point; the app lives in
# the tray. Every argument is forwarded so --startup still works.
$vbsBody = @"
Set sh = CreateObject("WScript.Shell")
sh.CurrentDirectory = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
extra = ""
For i = 0 To WScript.Arguments.Count - 1
  extra = extra & " " & WScript.Arguments(i)
Next
sh.Run """$pythonw"" rabbit_kit.py" & extra, 0, False
"@
Set-Content -Path $vbs -Value $vbsBody -Encoding ASCII

Write-Step "Registering background startup"
$identity = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$principal = New-ScheduledTaskPrincipal -UserId $identity -LogonType Interactive -RunLevel Highest
$taskSettings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
  -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew

if ($NoStartup) {
  # The user cleared "start when I sign in". Drop any task a previous install
  # left behind, otherwise the checkbox would only ever be able to turn it on.
  try {
    $existing = Get-ScheduledTask -TaskName "Rabbit Kit Background" -ErrorAction SilentlyContinue
    if ($existing) { Unregister-ScheduledTask -TaskName "Rabbit Kit Background" -Confirm:$false }
  } catch {
    Invoke-Schtasks @("/Delete", "/TN", "Rabbit Kit Background", "/F")
  }
  Write-Host "Startup on sign-in: off"
} else {
  $startupAction = New-ScheduledTaskAction -Execute "wscript.exe" -Argument "`"$vbs`" --startup" -WorkingDirectory $InstallDir
  $startupTrigger = New-ScheduledTaskTrigger -AtLogOn -User $identity
  $startupTask = New-ScheduledTask -Action $startupAction -Trigger $startupTrigger -Principal $principal -Settings $taskSettings
  Register-ScheduledTask -TaskName "Rabbit Kit Background" -InputObject $startupTask -Force | Out-Null
  Write-Host "Startup on sign-in: on"
}

$openAction = New-ScheduledTaskAction -Execute "wscript.exe" -Argument "`"$vbs`"" -WorkingDirectory $InstallDir
$openTask = New-ScheduledTask -Action $openAction -Principal $principal -Settings $taskSettings
Register-ScheduledTask -TaskName "Rabbit Kit Open" -InputObject $openTask -Force | Out-Null
$launcher = Join-Path $InstallDir "Rabbit Kit Launcher.vbs"
$launcherBody = @'
Set sh = CreateObject("WScript.Shell")
sh.Run "schtasks.exe /Run /TN ""Rabbit Kit Open""", 0, False
'@
Set-Content -Path $launcher -Value $launcherBody -Encoding ASCII

$startMenu = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"
Ensure-Dir $startMenu
# Shortcuts target wscript.exe, so without an explicit IconLocation they inherit
# the Windows Script Host icon. Point them at our own .ico.
$icon = Join-Path $InstallDir "assets\rabbit.ico"
New-Shortcut (Join-Path $startMenu "Rabbit Kit.lnk") "wscript.exe" "`"$launcher`"" $InstallDir $icon
$desktop = [Environment]::GetFolderPath("Desktop")
New-Shortcut (Join-Path $desktop "Rabbit Kit.lnk") "wscript.exe" "`"$launcher`"" $InstallDir $icon

Write-Step "Registering file types"
# Registered as ProgIds under HKCU only -- no admin, and it never *steals* an
# association. Windows still asks the user before switching a default, and
# "Open with > Rabbit Kit" works immediately either way.
$opener = Join-Path $InstallDir "RabbitOpen.exe"
if (Test-Path $opener) {
  foreach ($kind in $FileKinds.Keys) {
    $progId = "RabbitKit.$kind"
    $base   = "HKCU:\Software\Classes\$progId"
    New-Item -Path "$base\shell\open\command" -Force | Out-Null
    Set-ItemProperty -Path $base -Name "(Default)" -Value "Rabbit Kit $kind"
    New-Item -Path "$base\DefaultIcon" -Force | Out-Null
    Set-ItemProperty -Path "$base\DefaultIcon" -Name "(Default)" -Value "$icon,0"
    Set-ItemProperty -Path "$base\shell\open\command" -Name "(Default)" `
      -Value ("`"$opener`" `"%1`"")
    foreach ($ext in $FileKinds[$kind]) {
      # OpenWithProgids *adds* us to the "Open with" list without hijacking the
      # existing default. Making Rabbit Kit the default is the user's call, from
      # Settings, not something an installer should do behind their back.
      $withKey = "HKCU:\Software\Classes\$ext\OpenWithProgids"
      New-Item -Path $withKey -Force | Out-Null
      New-ItemProperty -Path $withKey -Name $progId -Value ([byte[]]@()) `
        -PropertyType None -Force | Out-Null
    }
  }
  Write-Host "Registered Image/Video/Audio/Text handlers"
}

Write-Step "Finishing up"
# Uninstaller stub. It mirrors the -Uninstall path above for people who go
# looking in the install folder instead of re-running setup.
$uninst = @"
@echo off
echo Removing Rabbit Kit...
schtasks /End /TN "Rabbit Kit Background" >nul 2>nul
schtasks /End /TN "Rabbit Kit Open" >nul 2>nul
schtasks /Delete /TN "Rabbit Kit Background" /F >nul 2>nul
schtasks /Delete /TN "Rabbit Kit Open" /F >nul 2>nul
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Rabbit Kit.lnk" 2>nul
del "%USERPROFILE%\Desktop\Rabbit Kit.lnk" 2>nul
reg delete "HKCU\Software\Classes\RabbitKit.Image" /f >nul 2>nul
reg delete "HKCU\Software\Classes\RabbitKit.Video" /f >nul 2>nul
reg delete "HKCU\Software\Classes\RabbitKit.Audio" /f >nul 2>nul
reg delete "HKCU\Software\Classes\RabbitKit.Text" /f >nul 2>nul
rd /s /q "$InstallDir"
echo Done.
echo.
echo Your notes, macros and snapshots were left alone in Documents\$DataDirName.
pause
"@
Set-Content (Join-Path $InstallDir "Uninstall.bat") $uninst -Encoding ASCII

Write-Host ""
Write-Host "Installed. Launching Rabbit Kit…" -ForegroundColor Green
Start-Process -FilePath "schtasks.exe" -ArgumentList "/Run /TN `"Rabbit Kit Open`"" -WindowStyle Hidden
if (-not $Quiet) {
  Write-Host "Press Enter to close setup."
  [void][Console]::ReadLine()
}
