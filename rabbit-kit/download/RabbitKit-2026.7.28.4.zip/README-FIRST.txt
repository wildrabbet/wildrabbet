RABBIT KIT 2026.7.28.4

1. Extract this ZIP to a normal folder.
2. Open the extracted folder.
3. Double-click "Install Rabbit Kit.cmd".
4. Accept the Windows administrator prompt.
