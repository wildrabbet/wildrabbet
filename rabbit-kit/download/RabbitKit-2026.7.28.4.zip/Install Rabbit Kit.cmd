@echo off
setlocal
title Rabbit Kit Setup

fltmc >nul 2>nul
if errorlevel 1 (
  echo Rabbit Kit needs administrator access to create its startup task.
  echo Windows will now ask for permission.
  powershell.exe -NoProfile -Command "Start-Process -FilePath '%ComSpec%' -Verb RunAs -ArgumentList '/d /c \"\"%~f0\" elevated\"'"
  exit /b
)

echo Installing Rabbit Kit from the files in this folder...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install.ps1" -PayloadZip "%~dp0payload.zip"
if errorlevel 1 (
  echo.
  echo Installation failed. Nothing was excluded from Microsoft Defender.
  pause
  exit /b 1
)

echo.
echo Rabbit Kit is installed.
pause
