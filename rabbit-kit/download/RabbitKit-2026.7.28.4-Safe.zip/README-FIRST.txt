RABBIT KIT 2026.7.28.4 - TRANSPARENT ZIP INSTALLER

1. Extract this ZIP to a normal folder.
2. Open the extracted folder.
3. Double-click "Install Rabbit Kit.cmd".
4. Accept the Windows administrator prompt.

This package replaces the custom self-extracting EXE that Microsoft Defender
classified as Trojan:Win32/Wacatac.B!ml. Do not disable Defender and do not
restore the quarantined EXE.

The ZIP contains three readable parts:

- Install Rabbit Kit.cmd: requests administrator permission and starts setup.
- Install.ps1: the complete, inspectable installation logic.
- payload.zip: Rabbit Kit's Python, HTML, assets, and configuration files.

The package does not add a Defender exclusion. Windows Defender should remain
enabled throughout installation.
